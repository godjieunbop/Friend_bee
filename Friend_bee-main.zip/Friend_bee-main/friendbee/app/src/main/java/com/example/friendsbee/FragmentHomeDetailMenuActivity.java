package com.example.friendsbee;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FragmentHomeDetailMenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_home_detail_menu);
    }
}