package com.example.friendsbee;

public class Code {
    public class ViewType{
        public static final int LEFT_CONTENT = 0;
        public static final int RIGHT_CONTENT= 1;
        public static final int CENTER_CONTENT =2;
    }
}
